package com.example.chattApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChattAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChattAppApplication.class, args);
	}

}
